import SwiftUI
import CoreImage
import UIKit

struct ContentView: View {
    @State private var showingImagePicker = false
    @State private var selectedImage: UIImage? = nil
    @State private var objColor: Color?
    
    var body: some View {
        VStack {
            if let image = selectedImage {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                
                if let objColor = objColor {
                    Text("Frog Color: \(objColor.description)")
                        .foregroundColor(objColor)
                }
            } else {
                Text ("No image selected")
            }
            Button("Select Image") {
                showingImagePicker = true  
            }
        }
        .sheet(isPresented: $showingImagePicker, onDismiss: loadImage) {
            ImagePicker(image: $selectedImage)
        }
    }
    
    func loadImage() {
        guard let selectedImage = selectedImage else { return }
        
//        objColor = getAverageColor(image: selectedImage)
        objColor = Color(uiColor: selectedImage.averageColor ?? .clear)
    }
    
    func getAverageColor(image: UIImage) -> UIColor? {
        guard let cgImage = image.cgImage else {
            return nil
        }
        
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let bytesPerPixel = 4
        let bytesPerRow = bytesPerPixel * cgImage.width
        let bitsPerComponent = 8
        let imageData = UnsafeMutableRawPointer.allocate(byteCount: cgImage.height * bytesPerRow, alignment: bytesPerPixel)
        defer {
            imageData.deallocate()
        }
        
        let context = CGContext(data: imageData, width: cgImage.width, height: cgImage.height, bitsPerComponent: bitsPerComponent, bytesPerRow: bytesPerRow, space: colorSpace, bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
        context.draw(cgImage, in: CGRect(x: 0, y: 0, width: cgImage.width, height: cgImage.height))
        
        let data = imageData.bindMemory(to: UInt8.self, capacity: cgImage.height * bytesPerRow)
        
        var totalRed: UInt32 = 0
        var totalGreen: UInt32 = 0
        var totalBlue: UInt32 = 0
        let pixelCount = cgImage.width * cgImage.height
        
        print(cgImage.height)
        
        for y in 0..<cgImage.height {
            for x in 0..<cgImage.width {
                let offset = y * bytesPerRow + x * bytesPerPixel
                let red = UInt32(data[offset])
                let green = UInt32(data[offset + 1])
                let blue = UInt32(data[offset + 2])
                totalRed += red
                totalGreen += green
                totalBlue += blue
            }
        }
        
        print(cgImage.width)
        
        let averageRed = CGFloat(totalRed) / CGFloat(pixelCount)
        let averageGreen = CGFloat(totalGreen) / CGFloat(pixelCount)
        let averageBlue = CGFloat(totalBlue) / CGFloat(pixelCount)
        
        return UIColor(red: averageRed / 255.0, green: averageGreen / 255.0, blue: averageBlue / 255.0, alpha: 1.0)
    }
}

extension UIImage {
    var averageColor: UIColor? {
        guard let inputImage = CIImage(image: self) else { return nil }
        let extentVector = CIVector(x: inputImage.extent.origin.x, y: inputImage.extent.origin.y, z: inputImage.extent.size.width, w: inputImage.extent.size.height)
        guard let filter = CIFilter(name: "CIAreaAverage", parameters: [kCIInputImageKey: inputImage, kCIInputExtentKey: extentVector]) else { return nil }
        guard let outputImage = filter.outputImage else { return nil }
        
        var bitmap = [UInt8](repeating: 0, count: 4)
        let context = CIContext()
        context.render(outputImage, toBitmap: &bitmap, rowBytes: 4, bounds: CGRect(x: 0, y: 0, width: 1, height: 1), format: CIFormat.RGBA8, colorSpace: nil)
        return UIColor(red: CGFloat(bitmap[0]) / 255.0, green: CGFloat(bitmap[1]) / 255.0, blue: CGFloat(bitmap[2]) / 255.0, alpha: CGFloat(bitmap[3]) / 255.0)
    }
}
